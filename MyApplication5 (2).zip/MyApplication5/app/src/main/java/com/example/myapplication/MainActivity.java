package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText x = findViewById(R.id.editTextTextPersonName);
        final EditText y = findViewById(R.id.editTextTextPassword);
        Button addis = findViewById(R.id.button2);
        Button addiss = findViewById(R.id.button3);
        Button addi = findViewById(R.id.button);
        addi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int ss = Integer.parseInt(x.getText().toString());
                int s1 = Integer.parseInt(y.getText().toString());
                int aaa = ss+ s1;
                Toast.makeText(MainActivity.this, aaa+"", Toast.LENGTH_SHORT).show();
            }
        });
        addis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int ss2 = Integer.parseInt(x.getText().toString());
                int s33 = Integer.parseInt(y.getText().toString());
                int sssss = ss2*s33;
                Toast.makeText(MainActivity.this, sssss+"", Toast.LENGTH_SHORT).show();
            }
        });
        addiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int de = Integer.parseInt(x.getText().toString());
                int da = Integer.parseInt(y.getText().toString());
                int za = de/da;
                Toast.makeText(MainActivity.this, za+"", Toast.LENGTH_SHORT).show();
            }
        });
    }
}